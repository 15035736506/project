## 项目配置      

* Python 3.7   
* PyTorch >= 1.5.1  



## 项目使用方法  
* step 1: python prepare_train_labels.py  
* step 2: python make_val_subset.py  
* step 3: python train.py  
* step 4: python inference_video.py  



## 开发说明

以上项目仅作为提供学习参考，完整代码请联系学长。

项目开发、毕设帮助、选题指导、任何开发问题都开源问我，乐意解答！

![1](C:\Users\husin\Desktop\workTemp\git广告备份\计算机专业广告\project-sharing-1-master\毕设指导\1.png)
