import pyttsx3

# weather=pyttsx3.init()
# n=0
# for i in range(20):
#     weather.say(str(i)+"个")
#     weather.runAndWait()

from win32com.client import Dispatch
speaker=Dispatch('SAPI.SpVoice')
speaker.Speak('123')
